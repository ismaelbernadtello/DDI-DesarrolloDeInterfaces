-- insertar regiones
INSERT INTO REGION (nombre) VALUES ('Kanto');
INSERT INTO REGION (nombre) VALUES ('Johto');
INSERT INTO REGION (nombre) VALUES ('Hoenn');
INSERT INTO REGION (nombre) VALUES ('Sinnoh');
INSERT INTO REGION (nombre) VALUES ('Unova');
INSERT INTO REGION (nombre) VALUES ('Kalos');
INSERT INTO REGION (nombre) VALUES ('Alola');
INSERT INTO REGION (nombre) VALUES ('Galar');

--insertar entrenadores
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Ash Ketchum', false);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Misty', false);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Brock', false);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Gary Oak', false);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Jessie', true);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('James', true);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Giovanni', true);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Lance', true);
INSERT INTO ENTRENADOR (nombre, activo) VALUES ('Steven', true);


--insertar pokemon con entrenador
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Pikachu', 1, 2);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Charizard', 1, 3);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Bulbasaur', 1, 4);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Squirtle', 1, 5);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Onix', 1, 6);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Arcanine', 1, 7);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Gyarados', 2, 2);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Lapras', 2, 3);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Snorlax', 2, 4);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Pidgeot', 2, 5);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Venusaur', 2, 6);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Meganium', 2, 7);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Typhlosion', 2, 8);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Feraligatr', 2, 9);


