package Paquete.Controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import Paquete.Modelos.*;
import Paquete.Repositorio.DuenoRepositorio;

@Controller
public class DuenoControlador {
    
    //Autowire sirve para que se cree una instancia de JdbcTemplate automáticamente. 
    // Lo que hace es que el objeto que creas debajo se instancie automáticamente
    @Autowired
    private DuenoRepositorio duenoRepositorio;

    //Si ponemos en la URL localhost:8080/listaDuenos, se ejecuta la función
    @RequestMapping("/listaDuenos") 
    public String listadoDuenos(Model model){
        List<Dueno> listaDuenos = duenoRepositorio.getTodosDuenos(); //Obtenemos la lista de todos los dueños
        model.addAttribute("listaDuenos", listaDuenos);
        return "listaDuenos"; //Nos redirige al archivo listaDuenos.html pasandole la lista de dueños
    }

    //Si ponemos en la URL localhost:8080/formInsertarDueno se ejecuta la función
    @RequestMapping("/formInsertarDueno")
    public String formInsertadoDueno(Model model){
        Dueno dueno = new Dueno();
        model.addAttribute("dueno", dueno);
        return "formDueno"; //Redirige a la página de formDueno.html
    }

    //Si ponemos en la URL localhost:8080/formModificarDueno y se pasa la variable dni se ejecuta la función
    @RequestMapping("/formModificarDueno/{dni}")
    public String formModificadoDueno(@PathVariable String dni, Model model){
                                    //PathVariable sirve para pasar variables por la URL, es lo que se ve localhost:8080/archivo/{variable}
                                    //Que en el navegador se ve como localhost:8080/formModificarDueno/12345678A
        Dueno dueno = duenoRepositorio.getDuenoPorDni(dni);
        if (dueno != null) {
            model.addAttribute("dueno", dueno);
            return "formModificarDueno"; //Redirige a la página de formModificarDueno.html
        }
        else{
            return "paginaError"; //Redirige a la página de paginaError.html
        }   
    }


    //Si ponemos en la URL localhost:8080/insertarDueno se ejecuta la función
    @RequestMapping("/insertarDueno")
    public String insertarNuevoDueno(Dueno dueno, Model model){
        System.out.println(dueno.getDni() + ", " + dueno.getNombre());
        duenoRepositorio.crearDueno(dueno);
        return listadoDuenos(model); //Redirige a la página de listaDuenos.html
    }

    //Si ponemos en la URL localhost:8080/actualizarDueno se ejecuta la función
    @RequestMapping("/actualizarDueno")
    public String actualizarDueno(Dueno dueno, Model model){
        System.out.println(dueno.getDni() + ", " + dueno.getNombre()); //Imprime por consola el dni y el nombre del dueño
        duenoRepositorio.actualizarDueno(dueno); //Actualiza el dueño con el metodo del repositorio
        return listadoDuenos(model); //Redirige a la página de listaDuenos.html
    }


    //PARA ELIMINAR HAY 2 FUNCIONES PORQUE TENEMOS UNA PÁGINA INTERMEDIA PARA CONFIRMAR LA ELIMINACIÓN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    //Si ponemos en la URL localhost:8080/avisoEliminarDueno y se pasa la variable dni se ejecuta la función
    @RequestMapping("/avisoEliminarDueno/{dni}")
    public String avisoEliminarDueno(@PathVariable String dni, Model model){
        Dueno dueno = duenoRepositorio.getDuenoPorDni(dni);
        if (dueno != null) {
            model.addAttribute("dueno", dueno);
            return "avisoEliminarDueno";
        }
        else{
            return "paginaError";
        }   
    }

    //Si ponemos en la URL localhost:8080/eliminarDueno y se pasa la variable dni se ejecuta la función
    @RequestMapping("/eliminarDueno/{dni}")
    public String eliminarDueno(@PathVariable String dni, Model model){
        Dueno dueno = duenoRepositorio.getDuenoPorDni(dni);
        if (dueno != null) { //Si no es null, el dueño existe y se puede eliminar
            duenoRepositorio.eliminarDueno(dueno); //Eliminamos el dueño
            return listadoDuenos(model); //Redirige a la página de listaDuenos.html
        }
        else{ //Si es null, el dueño no existe y no se puede eliminar
            return "paginaError"; //Redirige a la página de paginaError.html
        }   
    }


    public List<Dueno> getTodosDuenos(){
        return duenoRepositorio.getTodosDuenos();
    }

    public Dueno getDuenoPorDni(String dni){
        return duenoRepositorio.getDuenoPorDni(dni);
    }

}
