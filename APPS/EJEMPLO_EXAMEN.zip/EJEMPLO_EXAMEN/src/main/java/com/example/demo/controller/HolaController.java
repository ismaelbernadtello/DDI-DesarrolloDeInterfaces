package com.example.demo.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.HolaRowMapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public class HolaController {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @RequestMapping("/")
    public String Hola(Model model) {
        // PASO 2:
        model.addAttribute("hola", new com.example.demo.model.Hola());
        return "form";
    }

    @RequestMapping("/deleteHola/{id}")
    public String deleteHola(@PathVariable Integer id, Model model) {
        jdbcTemplate.update("DELETE FROM hola WHERE id=?", new Object[] { id });
        List<com.example.demo.model.Hola> holaLista = new ArrayList<>();
        jdbcTemplate.query("SELECT * FROM hola", new HolaRowMapper())
                .forEach(hola1 -> holaLista.add(hola1));
        model.addAttribute("holaLista", holaLista);
        return "result";
    }

    // PASO 4: recibe los datos del formulario y los inserta en la base de datos
    @RequestMapping("/insertHola")
    public String insertHola(com.example.demo.model.Hola hola, Model model) {
        if (hola.getId() != null) {
            jdbcTemplate.update("UPDATE hola SET nombre=?, email=?, contracena=?, rol=? WHERE id=?", hola.getNombre(),
                    hola.getEmail(), hola.getContracena(), hola.getRol(), hola.getId());
            return "result";
        } else {
            jdbcTemplate.update("INSERT INTO hola (nombre, email, contracena, rol) VALUES (?, ?, ?, ?)",
                    hola.getNombre(),
                    hola.getEmail(), hola.getContracena(), hola.getRol());
            model.addAttribute("hola", hola);
            System.out.println(hola.toString());
            List<com.example.demo.model.Hola> holaLista = new ArrayList<>();
            jdbcTemplate.query("SELECT * FROM hola", new HolaRowMapper())
                    .forEach(hola1 -> holaLista.add(hola1));
            model.addAttribute("holaLista", holaLista);
            return "result";
        }
    }

    @RequestMapping("/updateHola/{id}")
    public String updateHola(@PathVariable Integer id, Model model) {
        com.example.demo.model.Hola hola = jdbcTemplate.queryForObject("SELECT * FROM hola WHERE id=?",
                new Object[] { id }, new HolaRowMapper());
        model.addAttribute("hola", hola);
        return "form";
    }
}
