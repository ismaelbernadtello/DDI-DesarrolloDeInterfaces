package Paquete.Repositorio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import Paquete.Modelos.Dueno;

@Repository //Indica que es un repositorio
public class DuenoRepositorio {
    
    //Autowire sirve para que se cree una instancia de JdbcTemplate automáticamente
    //JdbcTemplate sirve para hacer consultas a la base de datos
    //HAY QUE PONER SIEMPRE EL jdbcTemplate SIEMPREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    @Autowired
    JdbcTemplate jdbcTemplate;

    //El ROWMAPPER solo se usa al hacer selecciones en la base de datos. Cuando se hace un insert, update o delete no se usa
    public List<Dueno> getTodosDuenos(){ //Devuelve una lista de dueños con todos los datos
        String query = "SELECT * FROM dueno;";
        List<Dueno> listaDuenos = jdbcTemplate.query(query, new DuenoRowMapper());
        //Se hace la query y se le pasa el RowMapper para que sepa como mapear los datos
        return listaDuenos;
    }
    
    public Dueno getDuenoPorDni(String dni){ //Delvuelve un dueño con todos los datos por su dni
        String query = "SELECT * FROM dueno d WHERE d.dni = ?";
        List<Dueno> listaDuenos = jdbcTemplate.query(query, new DuenoRowMapper(), dni);
        return (listaDuenos.isEmpty())? null: listaDuenos.get(0);
    }

    public void eliminarDueno(Dueno dueno){ //Elimina un dueño por su dni
        String query = "DELETE FROM dueno d WHERE d.dni = ?";
        jdbcTemplate.update(query, dueno.getDni());
    }

    public void actualizarDueno(Dueno dueno){ //Actualiza el nombre de un dueño por su dni
        String query = "UPDATE dueno SET nombre_apellidos = ? WHERE dni = ?";
        jdbcTemplate.update(query, dueno.getNombre(), dueno.getDni());
    }

    public void crearDueno(Dueno dueno){ //Crea un dueño con su dni y nombre
        String query = "INSERT INTO dueno (dni, nombre_apellidos) VALUES (?, ?)";
        jdbcTemplate.update(query, dueno.getDni(), dueno.getNombre());
    }
}
