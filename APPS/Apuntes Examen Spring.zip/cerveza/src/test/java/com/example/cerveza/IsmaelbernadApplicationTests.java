package com.example.cerveza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsmaelbernadApplicationTests {

	@Test
	void contextLoads() {
	}

}
