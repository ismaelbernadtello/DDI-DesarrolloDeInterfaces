package com.example.examenIsmaelBernad.Repositories;


import java.sql.ResultSet;
import java.sql.SQLException;

//Importamos la libreria de jdbc para poder usar RowMapper
import org.springframework.jdbc.core.RowMapper;

//Importamos la clase Region y Pokemon
import com.example.examenIsmaelBernad.Models.Region;
import com.example.examenIsmaelBernad.Models.Entrenador;
import com.example.examenIsmaelBernad.Models.Pokemon;


public class PokemonRowMapper implements RowMapper<Pokemon>{
    
    //Override se pone para sobreescribir el método mapRow por defectos
    @Override
    public Pokemon mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        //Se crea un objeto Pokemon con los datos del resultSet, que es el resultado de la query
        Region region = new Region();
        region.setId(resultSet.getInt("id_region"));
        region.setNombre(resultSet.getString("nombre_region"));

        //Creo un objeto entrenador para poder acceder a sus atributos
        Entrenador entrenador = new Entrenador();
        entrenador.setId(resultSet.getInt("id_entrenador"));
        entrenador.setNombre(resultSet.getString("nombre_entrenador"));

        Pokemon pokemon = new Pokemon();
        pokemon.setRegionPokemon(region); //Añado la region como objeto para poder acceder a sus atributos
        pokemon.setEntrenadorPokemon(entrenador); //Añado el entrenador como objeto para poder acceder a sus atributos
        pokemon.setId(resultSet.getInt("id"));
        pokemon.setNombre(resultSet.getString("nombre"));
        pokemon.setRegion(resultSet.getInt("id_region"));

        return pokemon;
    }


}
