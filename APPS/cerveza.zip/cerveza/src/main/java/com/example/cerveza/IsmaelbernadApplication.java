package com.example.cerveza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IsmaelbernadApplication {

	public static void main(String[] args) {
		SpringApplication.run(IsmaelbernadApplication.class, args);
	}

}
