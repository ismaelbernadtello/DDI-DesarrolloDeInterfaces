package Paquete.Repositorio;

import java.sql.ResultSet;
import java.sql.SQLException;

//Importamos la libreria de jdbc para poder usar RowMapper
import org.springframework.jdbc.core.RowMapper;

//Importamos el modelo de Dueno para poder usarlo en el método mapRow
import Paquete.Modelos.Dueno;

public class DuenoRowMapper implements RowMapper<Dueno>{
    //Override se pone para sobreescribir el método mapRow por defecto
    @Override
    public Dueno mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        //Se crea un objeto Dueno con los datos del resultSet, que es el resultado de la query
        Dueno dueno = new Dueno();
        dueno.setDni(resultSet.getString("dni"));
        dueno.setNombre(resultSet.getString("nombre_apellidos"));
        return dueno;
    }
    
}
