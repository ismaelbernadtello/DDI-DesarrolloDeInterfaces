package com.example.examenIsmaelBernad.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.examenIsmaelBernad.Models.Entrenador;
import com.example.examenIsmaelBernad.Models.Pokemon;
import com.example.examenIsmaelBernad.Repositories.EntrenadorRepositorio;
import com.example.examenIsmaelBernad.Repositories.PokemonRepositorio;


@Controller
public class EntrenadorController {
    //Autowire sirve para que se cree una instancia de JdbcTemplate automáticamente. 
    // Lo que hace es que el objeto que creas debajo se instancie automáticamente
    @Autowired
    private  EntrenadorRepositorio entrenadorRepositorio;

    @Autowired //Lo uso para poder emplear el controlador y obtener una lista de pokemon que tienen los entrenadores activos
    private PokemonRepositorio pokemonRepositorio;

    @RequestMapping("/formularioEntrenador")
    public String formInsertadoEntrenador(Model model){
        Entrenador entrenador = new Entrenador();
        model.addAttribute("entrenador", entrenador);
        return "formEntrenador"; //Redirige a la página de formEntrenador.html
    }

    @RequestMapping("/insertarEntrenador")
    public String insertarEntrenador(Entrenador entrenador){
        entrenadorRepositorio.crearEntrenador(entrenador);
        return "index"; //Redirige a la página principal
    }

    @RequestMapping("/listarPokemonEntrenadores")
    public String listarPokemonEntrenadores(Model model){
        model.addAttribute("listarPokemonEntrenadoresActivos", pokemonRepositorio.getTodosPokemonEntrenadoresActivos()); //Paso la lista de todos los pokemons para poder seleccionar cual queremos borrar desde la vista
        return "listadoPokemonEntrenador"; //Redirige a la página de listarPokemonEntrenadores.html
    }

    @RequestMapping("/listarEntrenadores")
    public String listarEntrenadores(Model model){
        model.addAttribute("listadoEntrenadores", entrenadorRepositorio.getTodosEntrenadores()); //Paso la lista de todos los pokemons para poder seleccionar cual queremos borrar desde la vista
        return "listadoEntrenadores"; //Redirige a la página de listarEntrenadores.html
    }

    @RequestMapping("/cambiarEstadoEntrenador/{idEntrenador}")
    public String cambiarEstadoEntrenador(Model model, @PathVariable int idEntrenador){
        Entrenador entrenador = new Entrenador();
        entrenador.setId(idEntrenador);
        entrenadorRepositorio.cambiarEstadoEntrenador(entrenador);
        return "index"; //Redirige a la página principal
    }

    public List<Entrenador> getTodosEntrenadores(){
        return entrenadorRepositorio.getTodosEntrenadores();
    }

    public List<Pokemon> getTodosEntrenadoresActivos(){
        return pokemonRepositorio.getTodosPokemonEntrenadoresActivos();
    }

    

}
