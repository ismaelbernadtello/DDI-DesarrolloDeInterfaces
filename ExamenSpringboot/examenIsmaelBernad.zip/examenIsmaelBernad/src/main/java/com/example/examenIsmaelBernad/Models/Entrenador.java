package com.example.examenIsmaelBernad.Models;

import lombok.Getter;
import lombok.Setter;

//Creo los getters y setters con lombok
@Getter
@Setter
public class Entrenador {
    private int id;
    private String nombre;
    private boolean activo;

    public Entrenador(int id, String nombre, boolean activo) {
        this.id = id;
        this.nombre = nombre;
        this.activo = activo;
    }

    public Entrenador() {
    }
}
