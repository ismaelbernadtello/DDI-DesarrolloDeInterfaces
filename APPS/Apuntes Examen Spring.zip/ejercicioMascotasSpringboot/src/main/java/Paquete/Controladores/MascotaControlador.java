package Paquete.Controladores;

import Paquete.Modelos.Mascota;
import Paquete.Modelos.Dueno;
import Paquete.Repositorio.MascotaRepositorio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MascotaControlador {
    
    //Autowired sirve para que se cree una instancia de JdbcTemplate automáticamente.
    // Lo que hace es que el objeto que creas debajo se instancie automáticamente
    @Autowired
    private MascotaRepositorio mascotaRepositorio;
    
    @Autowired
    private DuenoControlador duenoControlador;

    @RequestMapping("/listaMascotas") // Si ponemos en la URL localhost:8080/listaMascotas se ejecuta la función
    public String listaMascotas(Model model){
        List<Mascota> listaMascotas = mascotaRepositorio.getTodasMascotas(); //Obtenemos la lista de todas las mascotas
        model.addAttribute("listaMascotas", listaMascotas); //Añadimos la lista de mascotas al modelo, para pasarla a la vista
        return "listaMascotas"; //Nos redirige al archivo listaMascotas.html pasandole la lista de mascotas
    }

    @RequestMapping("/formMascota") // Si ponemos en la URL localhost:8080/formMascota se ejecuta la función
    public String formInsertarMascota(Model model){
        Mascota mascota = new Mascota(); //Creamos una nueva mascota
        model.addAttribute("nuevaMascota", mascota); //Añadimos la mascota al modelo, para pasarla a la vista
        model.addAttribute("listaDuenos", duenoControlador.getTodosDuenos()); //Añadimos la lista de dueños al modelo, para pasarla a la vista
        return "formMascota"; //Nos redirige al archivo formMascota.html
    }

    @RequestMapping("/insertarMascota") // Si ponemos en la URL localhost:8080/insertarMascota se ejecuta la función
    public String insertarMascota(Mascota mascota, @RequestParam String dniDueno, Model model){
        Dueno dueno = duenoControlador.getDuenoPorDni(dniDueno); //Obtenemos el dueño por su dni y lo guardamos en el objeto dueno
        mascota.setDueno(dueno); //Añadimos el dueño a la mascota
        mascotaRepositorio.insertarMascota(mascota); //Insertamos la mascota en la base de datos con el método insertarMascota del repositorio
        return listaMascotas(model); //Nos redirige al archivo listaMascotas.html
    }

    @RequestMapping("/formModificarMascota/{codigo}") // Si ponemos en la URL localhost:8080/formModificarMascota se ejecuta la función
    public String formModificarMascota(Model model, @PathVariable String codigo){
        Mascota mascota = mascotaRepositorio.getMascotaPorCodigo(Integer.parseInt(codigo)); //Obtenemos la mascota por su código y la guardamos en el objeto mascota
        model.addAttribute("mascota", mascota); //Añadimos la mascota al modelo, para pasarla a la vista
        model.addAttribute("listaDuenos", duenoControlador.getTodosDuenos()); //Añadimos la lista de dueños al modelo, para pasarla a la vista
        return "formModificarMascota"; //Nos redirige al archivo formModificarMascota.html pasandole la mascota y la lista de dueños
    }

    @RequestMapping("/actualizarMascota") // Si ponemos en la URL localhost:8080/actualizarMascota se ejecuta la función
    public String actualizarMascota(Mascota mascota, @RequestParam String dniDueno, Model model){
        Dueno dueno = duenoControlador.getDuenoPorDni(dniDueno); //Obtenemos el dueño por su dni y lo guardamos en el objeto dueno
        mascota.setDueno(dueno); //Añadimos el dueño a la mascota
        mascotaRepositorio.actualizarMascota(mascota); //Actualizamos la mascota en la base de datos con el método actualizarMascota del repositorio
        return listaMascotas(model); //Nos redirige al archivo listaMascotas.html
    }

    @RequestMapping("/eliminarMascota/{codigo}") // Si ponemos en la URL localhost:8080/eliminarMascota se ejecuta la función
    public String eliminarMascota(@PathVariable String codigo, Model model){
        Mascota mascota = mascotaRepositorio.getMascotaPorCodigo(Integer.parseInt(codigo)); //Obtenemos la mascota por su código y la guardamos en el objeto mascota
        mascotaRepositorio.eliminarMascota(mascota); //Eliminamos la mascota de la base de datos con el método eliminarMascota del repositorio
        return listaMascotas(model); //Nos redirige al archivo listaMascotas.html
    }
}
