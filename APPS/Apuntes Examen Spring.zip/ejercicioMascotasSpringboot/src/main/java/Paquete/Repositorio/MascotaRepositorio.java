package Paquete.Repositorio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import Paquete.Modelos.*;

@Repository //Indica que es un repositorio
public class MascotaRepositorio {
    
    //Autowire sirve para que se cree una instancia de JdbcTemplate automáticamente
    //JdbcTemplate sirve para hacer consultas a la base de datos
    //HAY QUE PONER SIEMPRE EL jdbcTemplate SIEMPREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<Mascota> getTodasMascotas(){ //Devuelve una lista de mascotas con sus datos y los datos del dueño
        List<Mascota> listaMascotas = jdbcTemplate.query(
            "SELECT m.codigo AS codigo, m.num_chip AS numChip, m.nombre AS nombreM, m.corriente_vacunacion AS corrVac, d.dni AS dniD, d.nombre_apellidos AS nomD FROM mascota AS m, dueno AS d WHERE m.dni_dueno = d.dni",
            new MascotaRowMapper());
        return listaMascotas;
    }
    
    public Mascota getMascotaPorCodigo(int codigoMascota){// Devuelve una mascota con todos los datos por su codigo
        String query = "SELECT m.codigo AS codigo, m.num_chip AS numChip, m.nombre AS nombreM, m.corriente_vacunacion AS corrVac, d.dni AS dniD, d.nombre_apellidos AS nomD FROM mascota m, dueno d WHERE m.dni_dueno = d.dni AND m.codigo = ?";
        List<Mascota> listaMascotas = jdbcTemplate.query(query, new MascotaRowMapper(), codigoMascota);
        return (listaMascotas.isEmpty())? null: listaMascotas.get(0);
    }
    //Recibe un dueño y devuelve una lista de mascotas que tienen el dni de ese dueño.
    public List<Mascota> getMascotasPorDueno(Dueno dueno){
        List<Mascota> listaMascotas = jdbcTemplate.query(
            "SELECT m.codigo, m.num_chip, m.nombre, m.corriente_vacunacion, d.dni, d.nombre_apellidos FROM mascota m, dueno d WHERE m.dni_dueno = d.dni AND d.dni = ?",
            new MascotaRowMapper(), dueno.getDni()); 
        return listaMascotas;
    }

    public void eliminarMascota(Mascota mascota){ //Elimina una mascota por su codigo
        String query = "DELETE FROM mascota m WHERE m.codigo = ?";
        jdbcTemplate.update(query, mascota.getCodigo());
    }

    public void actualizarMascota(Mascota mascota){ //Actualiza la mascota con su numChip, nombre, corrienteVacunacion y dniDueno
        String query = "UPDATE mascota SET num_chip = ?, nombre = ?, corriente_vacunacion = ?, dni_dueno = ? WHERE codigo = ?";
        jdbcTemplate.update(query,
            mascota.getNumChip(), mascota.getNombre(), mascota.getCorrienteVacunacion(), mascota.getDueno().getDni(), mascota.getCodigo());
    }

    public void insertarMascota(Mascota mascota){ //Crea una mascota con su numChip, nombre, corrienteVacunacion y dniDueno
        String query = "INSERT INTO mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (?, ?, ?, ?);";
        jdbcTemplate.update(query, mascota.getNumChip(), mascota.getNombre(), mascota.getCorrienteVacunacion(), mascota.getDueno().getDni());
    }
}
