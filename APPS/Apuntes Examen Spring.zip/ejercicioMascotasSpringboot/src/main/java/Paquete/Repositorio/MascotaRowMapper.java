package Paquete.Repositorio;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import Paquete.Modelos.Dueno;
import Paquete.Modelos.Mascota;

public class MascotaRowMapper implements RowMapper<Mascota> {

    //Override se pone para sobreescribir el método mapRow por defectos
    @Override
    public Mascota mapRow(ResultSet rs, int rowNum) throws SQLException {
        //Dentro de cada mascota creamos un dueño para poder acceder a sus atributos desde la vista y facilitar el uso de los datos
        //Si cuando se crea una mascota, la consulta no devuelve un dueño, la info del dueño se queda vacía
        Dueno dueno = new Dueno();
        dueno.setDni(rs.getString("dniD"));
        dueno.setNombre(rs.getString("nomD"));
        
        Mascota mascota = new Mascota();
        mascota.setDueno(dueno);
        mascota.setCodigo(rs.getInt("codigo"));
        mascota.setNumChip(rs.getInt("numChip"));
        mascota.setNombre(rs.getString("nombreM"));
        mascota.setCorrienteVacunacion(rs.getBoolean("corrVac"));
        return mascota;
    }
    
}
