package Paquete.Modelos;

//Clase Mascota con sus atributos y sus metodos get y set
public class Mascota { //Ponemos los mismos atributos que en la base de datos
    private int codigo;
    private int numChip;
    private String nombre;
    private Boolean corrienteVacunacion;

    //!!IMPORTANTE!!: En la clase Mascota, se crea un atributo de tipo Dueno para poder acceder a sus atributos desde la vista
    private Dueno dueno;


    //IMPORTANTE TENER UN CONSTRUCTOR VACIO, PORQUE SI NO NO FUNCIONA
    //NO SE PUEDE CREAR UNA MASCOTA SIN UN CONSTRUCTOR VACIO, PORQUE NO SE RECONOCE EL CONSTRUCTOR IMPLICITO
    public Mascota() {
    }

    public Mascota(int numChip, String nombre, Boolean corrienteVacunacion, Dueno dniDueno){
        this.numChip = numChip;
        this.nombre = nombre;
        this.corrienteVacunacion = corrienteVacunacion;
        this.dueno = dniDueno;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getNumChip() {
        return numChip;
    }

    public void setNumChip(int numChip) {
        this.numChip = numChip;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Boolean getCorrienteVacunacion() {
        return corrienteVacunacion;
    }

    public void setCorrienteVacunacion(Boolean corrienteVacunacion) {
        this.corrienteVacunacion = corrienteVacunacion;
    }

    public Dueno getDueno() {
        return dueno;
    }

    public void setDueno(Dueno dueno) {
        this.dueno = dueno;
    }
}
