package com.example.examenIsmaelBernad.Models;

import lombok.Getter;
import lombok.Setter;

//Creo los getters y setters con lombok
@Getter
@Setter
public class Pokemon {
    private int id;
    private String nombre;
    private int region;
    
    //Añado la region como objeto para poder acceder a sus atributos
    private Region regionPokemon; 
    
    //Añado el entrenador como objeto para poder acceder a sus atributos
    private Entrenador entrenadorPokemon;

    public Pokemon(int id, String nombre, int region, Region regionPokemon, Entrenador entrenadorPokemon) {
        this.id = id;
        this.nombre = nombre;
        this.region = region;
        this.regionPokemon = regionPokemon;
        this.entrenadorPokemon = entrenadorPokemon;
        
    }

    public Pokemon() {
    }

}
