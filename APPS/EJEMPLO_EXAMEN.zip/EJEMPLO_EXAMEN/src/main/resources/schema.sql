create table hola(
  id int NOT NULL AUTO_INCREMENT,
  nombre varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  contracena varchar(255) NOT NULL,
  rol varchar(255) NOT NULL
);
