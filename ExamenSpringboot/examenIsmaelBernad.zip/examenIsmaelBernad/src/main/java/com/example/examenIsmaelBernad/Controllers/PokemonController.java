package com.example.examenIsmaelBernad.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.examenIsmaelBernad.Models.Entrenador;
import com.example.examenIsmaelBernad.Models.Pokemon;
import com.example.examenIsmaelBernad.Models.Region;
import com.example.examenIsmaelBernad.Repositories.PokemonRepositorio;

@Controller
public class PokemonController {
    
    //Autowired sirve para que se cree una instancia de JdbcTemplate automáticamente.
    // Lo que hace es que el objeto que creas debajo se instancie automáticamente
    @Autowired
    private PokemonRepositorio pokemonRepositorio;

    @Autowired //Lo uso para poder emplear el controlador y obtener una lista de regiones
    private RegionController regionController;

    @Autowired //Lo uso para poder emplear el controlador y obtener una lista de entrenadores
    private EntrenadorController entrenadorController;

    @RequestMapping("/formularioPokemon")
    public String formInsertadoPokemon(Model model){
        Pokemon pokemon = new Pokemon();
        model.addAttribute("pokemon", pokemon);
        model.addAttribute("listaRegiones", regionController.getTodasRegiones()); //Añadimos la lista de regiones al modelo, para pasarla a la vista
        model.addAttribute("listaEntrenadores", entrenadorController.getTodosEntrenadores()); //Añadimos la lista de entrenadores al modelo, para pasarla a la vista
        return "formPokemon"; //Redirige a la página de formPokemon.html
    }

    @RequestMapping("/insertarPokemon")
    public String insertarPokemon(Pokemon pokemon, @RequestParam int idRegion, @RequestParam int idEntrenador, Model model){
        Pokemon pokemonCrear = new Pokemon();
        pokemonCrear.setNombre(pokemon.getNombre());
        pokemonCrear.setRegion(idRegion); //Guardo el id de la region en el pokemon

        Entrenador entrenador = new Entrenador();
        entrenador.setId(idEntrenador);
        pokemonCrear.setEntrenadorPokemon(entrenador); //Guardo el id del entrenador en el pokemon
        
        pokemonRepositorio.crearPokemon(pokemonCrear); //Creo el pokemon    
        return "index"; //Redirige a la página principal
    }

    @RequestMapping("/eliminarPokemon")
    public String eliminarPokemonForm(Model model){
        model.addAttribute("listaPokemon", pokemonRepositorio.getTodosPokemon()); //Paso la lista de todos los pokemons para poder seleccionar cual queremos borrar desde la vista
        return "eliminarPokemon"; //Redirige a la página de eliminarPokemon.html
    }

    @RequestMapping("/borradoPokemon")
    public String eliminarPokemon(@RequestParam int idPokemon, Model model){
        Pokemon pokemonABorrar = new Pokemon();
        pokemonABorrar.setId(idPokemon);
        pokemonRepositorio.eliminarPokemon(pokemonABorrar);
        return "index"; //Redirige a la página principal
    }

    @RequestMapping("/borrarPokemonListadoEntrenadoresActivos/{idPokemon}/{idEntrenador}") //Tengo que hacer otro método porque paso la id del pokemon por la url
    public String eliminarPokemonListadoEntrenadoresActivos(Model model, @PathVariable int idPokemon, @PathVariable int idEntrenador){
        Pokemon pokemonABorrar = new Pokemon();
        pokemonABorrar.setId(idPokemon);

        Entrenador entrenador = new Entrenador(); //Tengo que crear un objeto entrenador para darle valor y pasarlo al pokemon.
        entrenador.setId(idEntrenador); //Le doy el valor de la id del entrenador que le paso por la url
        entrenador.setActivo(true); //Le doy el valor de activo a true para que se pueda borrar el pokemon

        pokemonABorrar.setEntrenadorPokemon(entrenador);

        pokemonRepositorio.eliminarPokemon(pokemonABorrar);
        return "index"; //Redirige a la página principal
    }


    //Método para obtener todas la lista de los pokemon, que uso en el controlador de Pokemon para el desplegable de borrado
    public List<Pokemon> getTodosPokemons(){
        return pokemonRepositorio.getTodosPokemon();
    }
}
