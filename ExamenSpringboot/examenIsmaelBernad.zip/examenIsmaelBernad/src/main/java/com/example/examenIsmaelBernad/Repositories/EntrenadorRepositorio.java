package com.example.examenIsmaelBernad.Repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

//Importo la clase Entrenador
import com.example.examenIsmaelBernad.Models.Entrenador;

@Repository //Indica que es un repositorio
public class EntrenadorRepositorio {
    //Autowired sirve para que se cree una instancia de JdbcTemplate automáticamente
    //JdbcTemplate sirve para hacer consultas a la base de datos
    //HAY QUE PONER SIEMPRE EL jdbcTemplate SIEMPREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    @Autowired
    JdbcTemplate jdbcTemplate;

    public void crearEntrenador(Entrenador entrenador){ //Crea un entrenador con su nombre y si está activo o no
        String query = "INSERT INTO entrenador (nombre,activo) VALUES (?,?)";
        jdbcTemplate.update(query,entrenador.getNombre(),entrenador.isActivo());
    }

    public List<Entrenador> getTodosEntrenadores(){ //Devuelve una lista de entrenadores con todos los datos
        String query = "SELECT * FROM entrenador";
        List<Entrenador> listaEntrenadores = jdbcTemplate.query(query, new EntrenadorRowMapper());
        //Se hace la query y se le pasa el RowMapper para que sepa como mapear los datos
        return listaEntrenadores;
    }


    public List<Entrenador> getTodosEntrenadoresActivos(){ //Devuelve una lista de entrenadores con todos los datos
        String query = "SELECT * FROM entrenador WHERE activo = true";
        List<Entrenador> listaEntrenadores = jdbcTemplate.query(query, new EntrenadorRowMapper());
        //Se hace la query y se le pasa el RowMapper para que sepa como mapear los datos
        return listaEntrenadores;
    }

    public void cambiarEstadoEntrenador(Entrenador entrenador){ //Cambia el estado de un entrenador
        //Cambio el estado si es true a false y viceversa
        String query = "UPDATE entrenador SET activo = CASE WHEN activo = true THEN false ELSE true END WHERE id = ?";
        jdbcTemplate.update(query,entrenador.getId());
    }

}
