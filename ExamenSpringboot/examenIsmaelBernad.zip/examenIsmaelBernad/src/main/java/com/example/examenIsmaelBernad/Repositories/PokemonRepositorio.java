package com.example.examenIsmaelBernad.Repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

//Importo la clase Region y la clase Pokemon
import com.example.examenIsmaelBernad.Models.Region;
import com.example.examenIsmaelBernad.Models.Pokemon;

@Repository //Indica que es un repositorio
public class PokemonRepositorio {
    
    //Autowired sirve para que se cree una instancia de JdbcTemplate automáticamente
    //JdbcTemplate sirve para hacer consultas a la base de datos
    //HAY QUE PONER SIEMPRE EL jdbcTemplate SIEMPREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<Pokemon> getTodosPokemon(){ //Devuelve una lista de pokemon con todos los datos y con la informacion de la region y el entrenador. Esto es para luego guardarlo en el rowMapper
        String query = "SELECT p.*, r.id as id_region, r.nombre as nombre_region, e.id as id_entrenador, e.nombre as nombre_entrenador FROM pokemon as p, region as r, entrenador as e WHERE p.region = r.id AND e.id = p.entrenador_id";
        List<Pokemon> listaPokemon = jdbcTemplate.query(query, new PokemonRowMapper());
        //Se hace la query y se le pasa el RowMapper para que sepa como mapear los datos
        return listaPokemon;
    }

    public void crearPokemon(Pokemon pokemon){ //Crea un pokemon con su id, nombre, tipo y region
        String query = "INSERT INTO pokemon (nombre, region, entrenador_id) VALUES (?, ?, ?)";
        jdbcTemplate.update(query,pokemon.getNombre(), pokemon.getRegion(), pokemon.getEntrenadorPokemon().getId());
    }

    public void eliminarPokemon(Pokemon pokemon){ //Elimina un pokemon de la base de datos
        //Sistema de control para que no se puedan borrar pokemon si su entrenador no esta activo
        if(pokemon.getEntrenadorPokemon() != null && pokemon.getEntrenadorPokemon().isActivo()){ 
            String query = "DELETE FROM pokemon WHERE id = ?";
            jdbcTemplate.update(query, pokemon.getId());
        }
    }

    public List<Pokemon> getTodosPokemonEntrenadoresActivos(){ //Devuelve una lista de pokemon con todos los datos y con la informacion de la region y el entrenador. Esto es para luego guardarlo en el rowMapper
        String query = "SELECT p.*, r.id as id_region, r.nombre as nombre_region, e.id as id_entrenador, e.nombre as nombre_entrenador FROM pokemon as p, region as r, entrenador as e WHERE p.region = r.id AND e.id = p.entrenador_id AND e.activo = true";
        List<Pokemon> listaPokemon = jdbcTemplate.query(query, new PokemonRowMapper());
        //Se hace la query y se le pasa el RowMapper para que sepa como mapear los datos
        return listaPokemon;
    }

}
