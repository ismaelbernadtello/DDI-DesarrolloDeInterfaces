package com.example.examenIsmaelBernad.Repositories;

import java.sql.ResultSet;
import java.sql.SQLException;

//Importamos la libreria de jdbc para poder usar RowMapper
import org.springframework.jdbc.core.RowMapper;

//Importamos la clase Entrenador
import com.example.examenIsmaelBernad.Models.Entrenador;

public class EntrenadorRowMapper implements RowMapper<Entrenador>{
    //Override se pone para sobreescribir el método mapRow por defecto
    @Override
    public Entrenador mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        //Se crea un objeto Entrenador con los datos del resultSet, que es el resultado de la query
        Entrenador entrenador = new Entrenador();
        entrenador.setId(resultSet.getInt("id"));
        entrenador.setNombre(resultSet.getString("nombre"));
        entrenador.setActivo(resultSet.getBoolean("activo"));
        return entrenador;
    }
}
