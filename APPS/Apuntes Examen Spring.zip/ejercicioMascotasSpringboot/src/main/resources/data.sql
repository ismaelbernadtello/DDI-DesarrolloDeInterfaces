-- Insertar datos de en la base de datos.
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('12345678A', 'Paco Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('23456789B', 'Juan Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('34567891C', 'Lola Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('45678912D', 'Ernesto Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('56789123E', 'Bastar Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('67891234F', 'Zacarías Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('78912345G', 'Tomiris Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('89123456H', 'Apolo Parquez Parquiñez');
INSERT INTO Dueno (dni, nombre_apellidos) VALUES('91234567I', 'Al Parquez Parquiñez');
INSERT INTO Mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (0, 'Paco1', 1, '12345678A');
INSERT INTO Mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (1, 'Paco2', 1, '12345678A');
INSERT INTO Mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (2, 'Paco3', 1, '12345678A');
INSERT INTO Mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (3, 'Juan1', 1, '23456789B');
INSERT INTO Mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (4, 'Juan2', 1, '23456789B');
INSERT INTO Mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (5, 'Al1', 1, '91234567I');
INSERT INTO Mascota (num_chip, nombre, corriente_vacunacion, dni_dueno) VALUES (6, 'Al2', 0, '91234567I');